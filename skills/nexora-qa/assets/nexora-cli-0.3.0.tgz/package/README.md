# Nexora 图片 CLI

Node.js 22+ 的 TypeScript CLI，仅提供自由创作图片生成。复用云端 OAuth，直接调用图片 HTTP API。安装包内为编译后的 JavaScript，npm 自动生成 CMD 的 nexora.cmd，无需手写启动脚本。

## 三环境构建、安装和发布

Skill 分别为 dev 的 `nexora-dev`、qa 的 `nexora-qa`、prod 的 `nexora`，绑定独立 Git 仓库与服务。统一公开配置在 `config/agent-environments.json`，CLI 命令仍为 `nexora`。完整部署与回退见 [安装部署说明](../doc/plugin-install.md)。

```text
npx skills add terryoyty/nexora-skills-dev --skill nexora-dev
npx skills add terryoyty/nexora-skills-qa --skill nexora-qa
npx skills add terryoyty/nexora-skills --skill nexora
```

在 cli 目录先 `pnpm install --frozen-lockfile`，再执行 `pack.cmd dev|qa|prod` 或 `npm run pack:skill -- --env dev|qa|prod`。普通打包只检查、编译、生成和验证产物；远端发布单独执行 `npm run publish:git -- --env <环境>`。

产物在 `cli/release/<env>/repository/skills/<skill-name>/`，包含精确版本 CLI tgz、摘要、环境配置和完整文档；仓库发布目录为 `repository/`，验证归档留在本地。发布版本按内容生成不可变 tag；可在构建时用 `--release <新标识>`。后端只维护指南与公开信息，不读取本地发布目录。详细目录、发布失败恢复与 SQL/密钥/代理配置见上述部署说明。

每个 Skill 进程使用 `NEXORA_CONFIG_DIR=~/.nexora/dev|qa|prod`（展开用户目录）、`NEXORA_EXPECTED_SERVER=<该环境origin>`，并使用按 Skill/CLI版本隔离的绝对入口。dev 默认 `http://127.0.0.1:48080`，qa 为 `https://vimo.qa.aukeyit.com`，prod 为 `https://ai.aukeyit.com`。线上登录没有 HTTP 许可。手工 CLI 未设置环境绑定变量时保持原有显式 `--server` 行为。

## 本机 CLI 手工调试示例

在 cli 目录执行（CMD）：

```cmd
pack.cmd
npm install -g .\release\dev\repository\skills\nexora-dev\assets\nexora-cli-0.3.0.tgz
nexora --version
```

`pack.cmd` 自动切换到脚本所在目录，检查类型、构建、打包与临时安装验证；完整工作流回归执行 `pnpm test`。需要系统 tar.exe。脚本不会自动全局安装或登录。

当前版本产物：

- `cli/release/dev/repository/skills/nexora-dev/assets/nexora-cli-0.3.0.tgz`：dev Skill 配套 CLI 安装包。
- `cli/release/dev/repository/skills/nexora-dev/`：完整开发 Skill。
- `cli/release/dev/nexora-dev-<release-id>.tar.gz`：本地验证归档，解压得到仓库目录结构。

Skill 的 release.json 记录 CLI 版本、包路径、Node要求与 SHA-256。Agent 检查 Node22+/npm，不足时准备官方 LTS 到用户目录，校验并安装包内 CLI，按本环境发起浏览器授权。

Skill 模板在 [skills/nexora](../skills/nexora/SKILL.md)，由同一源码渲染三个名字。使用完整目录，不只复制 SKILL.md。CLI 图片命令继续使用 `nexora image ...`。

发布验证会解压分发包，在系统临时目录以独立 npm prefix 安装 CLI，检查版本和命令，随后清理临时目录。不会修改用户全局 CLI 或现有凭据。npm 安装依赖可能访问 registry，这不是离线发行包。若依赖已缓存，可设置 `NEXORA_RELEASE_TEST_OFFLINE=1` 让发布验证离线安装。

真实远端发布结果以 `cli/release/<env>/published.json` 的 commit/ref 为准。后端 release.json v2 仅提供环境、仓库和能力信息，安装统一使用 Git 来源，后端不提供下载接口或版本配置。OAuth 前提见 [接入文档](../doc/agent-oauth-mcp.md)。

## 登录及生成

将地址替换为已配置 issuer 的实际 origin，不能使用另一个主机名代替：

```cmd
nexora login --server http://127.0.0.1:48080 --allow-http
nexora auth status
nexora image options
nexora image generate --prompt "极简风格的香水产品海报"
nexora image generate --prompt "保留商品，背景改为海边日落" --reference "D:\商品.png"
```

login 自动发现、动态登记、打开浏览器并监听随机数值 loopback 端口，用户在网页确认。若浏览器未自动打开，复制 stderr 中的授权地址。默认 HTTPS；HTTP 仅在明确 --allow-http 时接受。CLI 与 MCP 独立登记、持有独立凭据，不读取 Agent Token。

凭据默认保存在用户目录 .nexora/credentials.json，POSIX目录0700/文件0600，Windows使用当前用户ACL；原子写和跨进程刷新锁。NEXORA_CONFIG_DIR 可指定独立配置目录。刷新响应不确定时需重新 login，不会重放旧 Refresh Token。

```cmd
nexora logout
```

先尝试撤销云端再清除本地；离线会说明撤销未确认，可到网页连接管理撤销。

## 参数及默认值

| 参数 | 默认/限制 |
| --- | --- |
| --prompt | 新请求必填，最多4000字 |
| --reference | 可重复，最多4张PNG/JPEG/WebP，每张10MiB |
| --reference-asset | 可重复，直接复用已有assetId；与本地图合计最多4张，顺序为本地图在前、资产在后 |
| --model | 自由创作功能点默认模型 |
| --count | 1，范围1～4 |
| --ratio / --image-size / --quality | 不传则用服务端模型默认；是否支持和值域查看 image options |
| --param key=value | 可重复，只允许当前模型公开schema字段，最多32项；按schema解析数字/布尔 |
| --brand | 本人已发布品牌风格编号，可省略 |
| --conversation | 本人会话，可省略新建 |
| --output | ./nexora-results/runId |
| --timeout | 1800秒，最大86400秒 |
| --no-wait | 默认等待并下载；指定后仅返回已受理身份 |
| --resume | 自动请求记录路径；仅可与timeout/no-wait/json同用 |
| --json | stdout单JSON envelope，进度写stderr |

同一参数不能通过别名和 --param 重复覆盖。模型没有唯一别名对应字段时用 --param 实际字段名=值。默认参数与价格由服务端功能点配置决定，不在CLI写死。

### 复用已生成的参考图

```cmd
nexora image generate --prompt "保留猫咪，背景改成花园" --reference-asset ASSET_ID --no-wait --json
```

ASSET_ID 来自之前下载结果的 `files[].assetId`，不使用 fileId 或下载URL。也可以直接把原下载目录中的图片传给 `--reference`：CLI匹配同目录manifest、大小和SHA-256，校验账号/服务及原Run实时结果后复用，不创建上传会话。文件已修改或没有匹配清单则正常上传；身份不符或原资产失效会报错，不静默重传。显式引用与自动识别使用后端已有归属和状态校验，不改后端业务。

新任务使用版本2恢复记录，将参考图来源及顺序纳入摘要；自动复用后即使本地文件移走，也可按原记录继续。兼容版本1记录。此能力避免重复上传已识别生成图，不提供任意本地图片全局去重，也不删除OSS已有副本。

## 状态、恢复与下载

```cmd
nexora image generate --prompt "极简海报" --no-wait --json
nexora image status RUN_ID --json
nexora image wait RUN_ID --timeout 1800 --json
nexora image download RUN_ID --output ".\results" --json
nexora image generate --resume ".\.nexora-requests\请求编号.json"
```

CLI 在上传和提交前自动保存请求记录，并在上传会话/资产/受理推进后更新；stderr、成功结果以及失败时的 `error.recovery` 提供记录路径，不要求用户准备JSON。恢复检查主体、服务器、资源、输入摘要和未受理请求的本地文件内容，沿用原幂等键。提交响应丢失时必须使用原记录，不能重新执行相同prompt创建新键。上传会话已过期时会报错，需确认原请求未受理后重新开始。

中断或超时不取消云端。download可在部分成功时下载已有文件，manifest.json记录稳定资产/文件ID及实际SHA-256，不保存签名URL。已有文件通过清单与大小/摘要校验后跳过，否则拒绝覆盖；随机.part排他写入、校验后落盘，拒绝符号链接目录和不可信重定向。签名过期自动重查一次；向存储请求不发送API Token。

输出形如 {"ok":true,"code":0,"data":{...}}。失败时为 `error.message`，有恢复上下文时额外包含 `error.recovery`：`action` 为 resume/status/wait/download，附适用的 record/runId/output。需要先处理参数或授权错误，恢复动作不等于无限自动重试。API密钥、Token和签名URL不进入错误文本/请求记录/下载清单。

```json
{"ok":false,"code":6,"error":{"message":"网络请求失败或超时","recovery":{"action":"resume","record":"D:\\work\\.nexora-requests\\原编号.json"}}}
```

| 退出码 | 含义 |
| --- | --- |
| 0 | 查询成功、全部交付或明确已受理 |
| 2 | 参数或契约格式错误 |
| 3 | 未登录、权限不足或认证失败 |
| 4 | 云端业务失败/取消 |
| 5 | 部分成功 |
| 6 | 网络、等待超时或提交结果不确定 |
| 7 | 下载失败（优先于云端部分失败） |
| 130 | 中断 |

测试只调用本地替身；真实图片生成会消耗云端额度，需要用户主动执行。
